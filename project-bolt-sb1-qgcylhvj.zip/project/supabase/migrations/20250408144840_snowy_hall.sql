/*
  # Fix admin policy for submissions table

  1. Changes
    - Remove dependency on users table for admin policy
    - Use email domain check directly from auth.jwt()
  
  2. Security
    - Maintains existing RLS policies
    - Updates admin policy to use built-in auth functions
*/

BEGIN;

-- Drop the existing admin policy
DROP POLICY IF EXISTS "Admins have full access" ON submissions;

-- Create new admin policy using auth.jwt() instead of users table
CREATE POLICY "Admins have full access"
ON submissions
FOR ALL
TO authenticated
USING (
  (auth.jwt() ->> 'email')::text LIKE '%@admin.local'
)
WITH CHECK (
  (auth.jwt() ->> 'email')::text LIKE '%@admin.local'
);

COMMIT;