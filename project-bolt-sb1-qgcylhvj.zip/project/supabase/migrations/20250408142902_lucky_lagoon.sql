/*
  # Initial Schema Setup for Cancer Treatment Database

  1. Extensions
    - Enable pg_trgm for fuzzy text search capabilities
  
  2. New Tables
    - `submissions`: Core table for treatment submissions
      - `id` (uuid, primary key)
      - `created_at` (timestamp with timezone)
      - `updated_at` (timestamp with timezone)
      - `anon_user_id` (uuid, nullable)
      - `cancer_type` (text)
      - `treatment_description` (text)
      - `treatment_tags` (text[])
      - `outcome` (text)
      - `timeframe` (text)
      - `status` (text)
      - `user_email_hash` (text, nullable)

  3. Security
    - Enable RLS on submissions table
    - Add policies for:
      - Public insert
      - Public read of approved submissions
      - Admin full access
      - User access to own submissions
*/

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- Create submissions table
CREATE TABLE IF NOT EXISTS submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  anon_user_id uuid,
  cancer_type text NOT NULL,
  treatment_description text NOT NULL,
  treatment_tags text[] DEFAULT '{}',
  outcome text NOT NULL,
  timeframe text,
  status text DEFAULT 'pending',
  user_email_hash text,
  CONSTRAINT valid_status CHECK (status IN ('pending', 'approved', 'rejected'))
);

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER submissions_updated_at
  BEFORE UPDATE ON submissions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

-- Enable RLS
ALTER TABLE submissions ENABLE ROW LEVEL SECURITY;

-- Policies

-- Allow public inserts
CREATE POLICY "Allow public inserts" ON submissions
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Allow public to read approved submissions
CREATE POLICY "Allow public to read approved submissions" ON submissions
  FOR SELECT
  TO public
  USING (status = 'approved');

-- Allow authenticated users to read and update their own submissions
CREATE POLICY "Users can read own submissions" ON submissions
  FOR SELECT
  TO authenticated
  USING (anon_user_id = auth.uid());

CREATE POLICY "Users can update own submissions" ON submissions
  FOR UPDATE
  TO authenticated
  USING (anon_user_id = auth.uid())
  WITH CHECK (anon_user_id = auth.uid());

-- Allow admins full access
CREATE POLICY "Admins have full access" ON submissions
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.users.id = auth.uid()
      AND auth.users.email LIKE '%@admin.cancerdb.org'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.users.id = auth.uid()
      AND auth.users.email LIKE '%@admin.cancerdb.org'
    )
  );

-- Create rate limiting table
CREATE TABLE IF NOT EXISTS rate_limits (
  ip_address text PRIMARY KEY,
  last_submission timestamptz DEFAULT now(),
  submission_count integer DEFAULT 1
);

-- Enable RLS on rate_limits
ALTER TABLE rate_limits ENABLE ROW LEVEL SECURITY;

-- Only allow service role to access rate_limits
CREATE POLICY "Service role only" ON rate_limits
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);