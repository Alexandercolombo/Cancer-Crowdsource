/*
  # Add submission history tracking

  1. Changes
    - Add parent_submission_id to submissions table to track update history
    - Add RLS policies for authenticated users to view their submissions
    - Add index on anon_user_id for better query performance

  2. Security
    - Enable RLS policies for authenticated users to:
      - View their own submissions
      - Create new submissions linked to their user ID
*/

-- Add parent_submission_id column to track update history
ALTER TABLE submissions 
ADD COLUMN IF NOT EXISTS parent_submission_id uuid REFERENCES submissions(id);

-- Add index for faster user submission queries
CREATE INDEX IF NOT EXISTS idx_submissions_anon_user_id 
ON submissions(anon_user_id);

-- Add RLS policies for authenticated users
CREATE POLICY "Users can view own submissions"
ON submissions
FOR SELECT
TO authenticated
USING (anon_user_id = auth.uid());

CREATE POLICY "Users can create submissions"
ON submissions
FOR INSERT
TO authenticated
WITH CHECK (
  -- Allow only if the submission is linked to the authenticated user
  anon_user_id = auth.uid()
);