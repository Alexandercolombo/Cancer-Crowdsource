/*
  # Update Admin Policy Email Pattern

  1. Changes
    - Update the admin policy to use @admin.local instead of @admin.cancerdb.org
    - Re-create the policy to ensure clean update
*/

DO $$ 
BEGIN
  -- Drop existing admin policy
  DROP POLICY IF EXISTS "Admins have full access" ON submissions;

  -- Create updated policy
  CREATE POLICY "Admins have full access" ON submissions
    FOR ALL
    TO authenticated
    USING (
      EXISTS (
        SELECT 1 FROM auth.users
        WHERE auth.users.id = auth.uid()
        AND auth.users.email LIKE '%@admin.local'
      )
    )
    WITH CHECK (
      EXISTS (
        SELECT 1 FROM auth.users
        WHERE auth.users.id = auth.uid()
        AND auth.users.email LIKE '%@admin.local'
      )
    );
END $$;