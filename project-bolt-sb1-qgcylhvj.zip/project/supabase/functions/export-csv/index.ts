import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'npm:@supabase/supabase-js@2.39.0';

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    // Verify admin authentication
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);

    if (authError || !user?.email?.endsWith('@admin.local')) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Fetch approved submissions
    const { data: submissions, error: fetchError } = await supabase
      .from('submissions')
      .select('cancer_type,treatment_description,treatment_tags,outcome,timeframe,created_at')
      .eq('status', 'approved')
      .order('created_at', { ascending: true });

    if (fetchError) {
      throw fetchError;
    }

    // Convert to CSV
    const headers = ['Cancer Type', 'Treatment Description', 'Treatment Tags', 'Outcome', 'Timeframe', 'Submission Date'];
    const rows = submissions.map(s => [
      s.cancer_type,
      s.treatment_description,
      (s.treatment_tags || []).join('; '),
      s.outcome,
      s.timeframe || '',
      new Date(s.created_at).toISOString().split('T')[0]
    ]);

    const csv = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${(cell || '').replace(/"/g, '""')}"`).join(','))
    ].join('\n');

    return new Response(
      csv,
      { 
        headers: { 
          ...corsHeaders,
          'Content-Type': 'text/csv',
          'Content-Disposition': 'attachment; filename="cancer-treatments.csv"'
        } 
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});