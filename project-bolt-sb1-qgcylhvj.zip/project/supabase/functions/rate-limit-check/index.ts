import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'npm:@supabase/supabase-js@2.39.0';

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const MAX_SUBMISSIONS = 5;
const WINDOW_HOURS = 1;

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const ip = req.headers.get('x-real-ip') || req.headers.get('x-forwarded-for');
    
    if (!ip) {
      return new Response(
        JSON.stringify({ error: 'Could not determine IP address' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { data: rateLimit } = await supabase
      .from('rate_limits')
      .select('*')
      .eq('ip_address', ip)
      .single();

    const now = new Date();
    
    if (rateLimit) {
      const lastSubmission = new Date(rateLimit.last_submission);
      const hoursSinceLastSubmission = (now.getTime() - lastSubmission.getTime()) / (1000 * 60 * 60);

      if (hoursSinceLastSubmission < WINDOW_HOURS) {
        if (rateLimit.submission_count >= MAX_SUBMISSIONS) {
          return new Response(
            JSON.stringify({ 
              allowed: false, 
              error: 'Rate limit exceeded. Please try again later.' 
            }),
            { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        await supabase
          .from('rate_limits')
          .update({ 
            submission_count: rateLimit.submission_count + 1,
            last_submission: now.toISOString()
          })
          .eq('ip_address', ip);
      } else {
        await supabase
          .from('rate_limits')
          .update({ 
            submission_count: 1,
            last_submission: now.toISOString()
          })
          .eq('ip_address', ip);
      }
    } else {
      await supabase
        .from('rate_limits')
        .insert({ 
          ip_address: ip,
          submission_count: 1,
          last_submission: now.toISOString()
        });
    }

    return new Response(
      JSON.stringify({ allowed: true }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});