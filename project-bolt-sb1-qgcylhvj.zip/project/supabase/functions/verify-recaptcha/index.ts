import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';

const RECAPTCHA_SECRET = Deno.env.get('RECAPTCHA_SECRET_KEY');
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { token } = await req.json();

    if (!token) {
      return new Response(
        JSON.stringify({ error: 'reCAPTCHA token is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const verificationUrl = 'https://www.google.com/recaptcha/api/siteverify';
    const formData = new URLSearchParams({
      secret: RECAPTCHA_SECRET!,
      response: token,
    });

    const result = await fetch(verificationUrl, {
      method: 'POST',
      body: formData,
    });

    const data = await result.json();

    return new Response(
      JSON.stringify(data),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});