import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { Database, PlusCircle, Home, Settings, Heart } from 'lucide-react';
import HomePage from './components/HomePage';
import SubmissionForm from './components/SubmissionForm';
import PublicView from './components/PublicView';
import AdminDashboard from './components/AdminDashboard';
import AdminLogin from './components/AdminLogin';
import MyUpdates from './components/MyUpdates';
import ProtectedRoute from './components/ProtectedRoute';

function NavLink({ to, children }: { to: string; children: React.ReactNode }) {
  const location = useLocation();
  const isActive = location.pathname === to;
  
  return (
    <Link
      to={to}
      className={`nav-link ${isActive ? 'active' : ''}`}
    >
      {children}
    </Link>
  );
}

function App() {
  return (
    <Router>
      <div className="min-h-screen flex flex-col bg-gray-50">
        <nav className="bg-white border-b border-gray-100 sticky top-0 z-10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-16">
              <div className="flex items-center">
                <Link to="/" className="flex items-center mr-8">
                  <Heart className="h-6 w-6 text-blue-600 mr-2" />
                  <span className="font-semibold text-xl text-gray-900">
                    Cancer Treatment DB
                  </span>
                </Link>

                <div className="flex items-center space-x-1">
                  <NavLink to="/">
                    <Home className="h-5 w-5 mr-2" />
                    <span>Home</span>
                  </NavLink>
                  
                  <NavLink to="/submit">
                    <PlusCircle className="h-5 w-5 mr-2" />
                    <span>Share Experience</span>
                  </NavLink>

                  <NavLink to="/data">
                    <Database className="h-5 w-5 mr-2" />
                    <span>Browse Data</span>
                  </NavLink>

                  <NavLink to="/admin">
                    <Settings className="h-5 w-5 mr-2" />
                    <span>Admin</span>
                  </NavLink>
                </div>
              </div>
            </div>
          </div>
        </nav>

        <main className="flex-grow">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/submit" element={<SubmissionForm />} />
              <Route path="/data" element={<PublicView />} />
              <Route path="/admin/login" element={<AdminLogin />} />
              <Route path="/my-updates" element={<MyUpdates />} />
              <Route
                path="/admin"
                element={
                  <ProtectedRoute>
                    <AdminDashboard />
                  </ProtectedRoute>
                }
              />
            </Routes>
          </div>
        </main>

        <footer className="bg-white border-t border-gray-100 mt-auto">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="text-center">
              <p className="text-gray-500 text-sm">
                © {new Date().getFullYear()} Cancer Treatment Database. All rights reserved.
              </p>
              <p className="text-gray-400 text-sm mt-2">
                This site is for information sharing only. Please consult healthcare professionals before making medical decisions.
              </p>
            </div>
          </div>
        </footer>
      </div>
    </Router>
  );
}

export default App;