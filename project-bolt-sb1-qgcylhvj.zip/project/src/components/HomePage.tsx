import React from 'react';
import { Link } from 'react-router-dom';
import { FileText, Shield, CheckCircle2, Search, Heart, ArrowRight } from 'lucide-react';

export default function HomePage() {
  return (
    <div className="space-y-20">
      {/* Hero Section */}
      <section className="text-center py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-white to-blue-50 rounded-3xl">
        <div className="max-w-3xl mx-auto">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-blue-100 mb-8">
            <Heart className="w-10 h-10 text-blue-600" />
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-6">
            Sharing Real-World Cancer Treatment Experiences
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            An anonymous, patient-driven platform to share and discover insights about cancer treatments
            based on real-world outcomes.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/submit" className="btn-primary inline-flex items-center">
              Share Your Experience
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
            <Link to="/data" className="btn-secondary inline-flex items-center">
              Browse Shared Data
              <Search className="ml-2 h-5 w-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-8">
          Our Mission
        </h2>
        <div className="prose prose-lg mx-auto text-gray-600">
          <p className="mb-4">
            The Cancer Treatment Database aims to create a comprehensive repository of real-world
            experiences from cancer patients who have undergone various treatments, both conventional
            and complementary.
          </p>
          <p>
            By collecting and sharing these experiences anonymously, we hope to provide valuable
            insights that can help others make informed decisions about their treatment journey
            while contributing to the broader understanding of cancer treatment outcomes.
          </p>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="bg-white py-16 px-4 sm:px-6 rounded-3xl">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            How It Works
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-100 mb-6">
                <FileText className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Share Anonymously</h3>
              <p className="text-gray-600">
                Submit your treatment experiences securely and anonymously. Your personal identity
                is never stored or shared.
              </p>
            </div>
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-100 mb-6">
                <Shield className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Data Review</h3>
              <p className="text-gray-600">
                Submissions are reviewed by administrators to ensure relevance and appropriateness
                before being made public.
              </p>
            </div>
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-100 mb-6">
                <Search className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Discover Insights</h3>
              <p className="text-gray-600">
                Browse approved, anonymized data shared by others to learn about different
                approaches and outcomes.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Why Participate Section */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
          Why Your Contribution Matters
        </h2>
        <div className="grid md:grid-cols-2 gap-12">
          <div className="bg-white p-8 rounded-xl border border-gray-100">
            <h3 className="text-xl font-semibold mb-4">For Those Sharing</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <CheckCircle2 className="w-5 h-5 text-green-500 mt-1 mr-3 flex-shrink-0" />
                <span>Help others make informed decisions about their treatment options</span>
              </li>
              <li className="flex items-start">
                <CheckCircle2 className="w-5 h-5 text-green-500 mt-1 mr-3 flex-shrink-0" />
                <span>Contribute to a growing knowledge base of treatment experiences</span>
              </li>
              <li className="flex items-start">
                <CheckCircle2 className="w-5 h-5 text-green-500 mt-1 mr-3 flex-shrink-0" />
                <span>Share your journey while maintaining complete anonymity</span>
              </li>
            </ul>
          </div>
          <div className="bg-white p-8 rounded-xl border border-gray-100">
            <h3 className="text-xl font-semibold mb-4">For Those Seeking Information</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <CheckCircle2 className="w-5 h-5 text-green-500 mt-1 mr-3 flex-shrink-0" />
                <span>Access real-world experiences from other patients</span>
              </li>
              <li className="flex items-start">
                <CheckCircle2 className="w-5 h-5 text-green-500 mt-1 mr-3 flex-shrink-0" />
                <span>Learn about various treatment approaches and their outcomes</span>
              </li>
              <li className="flex items-start">
                <CheckCircle2 className="w-5 h-5 text-green-500 mt-1 mr-3 flex-shrink-0" />
                <span>Make more informed decisions about your own treatment journey</span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* Trust & Disclaimer Section */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="bg-blue-50 border border-blue-100 rounded-xl p-8">
          <h2 className="text-2xl font-semibold text-gray-900 mb-6">
            Your Privacy & Important Disclaimer
          </h2>
          <div className="space-y-4 text-blue-900">
            <p>
              We are committed to protecting your privacy. All submissions are completely anonymous,
              and we never collect or store personally identifiable information unless explicitly
              provided for updates.
            </p>
            <p className="font-medium">
              This site is for informational sharing purposes only. The information shared is based
              on individual experiences and has not been medically validated. Always consult with
              qualified healthcare professionals before making any medical decisions.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}