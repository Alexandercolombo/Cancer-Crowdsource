import React, { useState, useEffect } from 'react';
import { CANCER_TYPES, OUTCOMES } from '../types';
import { supabase } from '../lib/supabase';
import { AlertCircle, CheckCircle2, FileText, Info } from 'lucide-react';
import TagInput from './TagInput';

interface Tag {
  id: string;
  text: string;
}

export default function SubmissionForm() {
  const [formData, setFormData] = useState({
    cancer_type: '',
    treatment_description: '',
    outcome: '',
    timeframe: '',
    email: ''
  });
  const [tags, setTags] = useState<Tag[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [isUpdate, setIsUpdate] = useState(false);

  useEffect(() => {
    loadPreviousSubmission();
  }, []);

  const loadPreviousSubmission = async () => {
    const lastSubmissionId = sessionStorage.getItem('lastSubmissionId');
    if (!lastSubmissionId) return;

    try {
      const { data: submission, error } = await supabase
        .from('submissions')
        .select('*')
        .eq('id', lastSubmissionId)
        .single();

      if (error) throw error;
      if (submission) {
        setFormData({
          cancer_type: submission.cancer_type,
          treatment_description: submission.treatment_description,
          outcome: '',
          timeframe: '',
          email: ''
        });
        setTags(submission.treatment_tags.map(tag => ({ id: tag, text: tag })));
        setIsUpdate(true);
      }
    } catch (err) {
      console.error('Error loading previous submission:', err);
    } finally {
      // Clear the stored ID to prevent pre-filling on future fresh submissions
      sessionStorage.removeItem('lastSubmissionId');
    }
  };

  const handleTagDelete = (index: number) => {
    setTags(tags.filter((_, i) => i !== index));
  };

  const handleTagAddition = (tag: Tag) => {
    setTags([...tags, tag]);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      // Check rate limit
      const rateLimitRes = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/rate-limit-check`, {
        headers: {
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
      });
      
      const rateLimitData = await rateLimitRes.json();
      if (!rateLimitData.allowed) {
        throw new Error(rateLimitData.error || 'Rate limit exceeded');
      }

      let anon_user_id = undefined;
      if (formData.email) {
        const { data: authData, error: authError } = await supabase.auth.signInWithOtp({
          email: formData.email,
        });
        
        if (authError) throw authError;
        anon_user_id = authData?.user?.id;
      }

      const { error: submitError } = await supabase.from('submissions').insert({
        cancer_type: formData.cancer_type,
        treatment_description: formData.treatment_description,
        treatment_tags: tags.map(tag => tag.text),
        outcome: formData.outcome,
        timeframe: formData.timeframe || null,
        anon_user_id,
        parent_submission_id: isUpdate ? sessionStorage.getItem('lastSubmissionId') : null
      });

      if (submitError) throw submitError;

      setSuccess(true);
      setFormData({
        cancer_type: '',
        treatment_description: '',
        outcome: '',
        timeframe: '',
        email: ''
      });
      setTags([]);
      setIsUpdate(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-100 mb-4">
          <FileText className="w-8 h-8 text-blue-600" />
        </div>
        <h1 className="text-3xl font-bold text-gray-900">
          {isUpdate ? 'Update Your Treatment Experience' : 'Share Your Treatment Experience'}
        </h1>
        <p className="mt-2 text-lg text-gray-600">
          {isUpdate 
            ? 'Share your latest progress and treatment updates'
            : 'Help others by sharing your cancer treatment journey'
          }
        </p>
      </div>

      {isUpdate && (
        <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 mb-8 flex items-start gap-3">
          <Info className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
          <div className="text-sm text-blue-800">
            <p className="font-medium mb-1">Updating Your Previous Submission</p>
            <p>
              We've pre-filled some details from your last update. Please review and update
              all fields to reflect your current status.
            </p>
          </div>
        </div>
      )}
      
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-100 rounded-lg flex items-center gap-3 text-red-700">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {success && (
        <div className="mb-6 p-4 bg-green-50 border border-green-100 rounded-lg flex items-center gap-3 text-green-700">
          <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
          <div>
            <p className="font-medium">Thank you for sharing your experience!</p>
            {formData.email && (
              <p className="text-sm mt-1">Check your email for an update link.</p>
            )}
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6 bg-white rounded-xl shadow-sm border border-gray-100 p-8">
        <div>
          <label className="form-label" htmlFor="cancer_type">
            Cancer Type <span className="text-red-500">*</span>
          </label>
          <select
            id="cancer_type"
            required
            value={formData.cancer_type}
            onChange={(e) => setFormData(prev => ({ ...prev, cancer_type: e.target.value }))}
            className="form-input"
          >
            <option value="">Select cancer type</option>
            {CANCER_TYPES.map(type => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="form-label" htmlFor="treatment_description">
            Treatment Description <span className="text-red-500">*</span>
          </label>
          <textarea
            id="treatment_description"
            required
            value={formData.treatment_description}
            onChange={(e) => setFormData(prev => ({ ...prev, treatment_description: e.target.value }))}
            className="form-input min-h-[120px]"
            placeholder="Please describe your treatment approach in detail..."
          />
          <p className="mt-1.5 text-sm text-gray-500">
            Include details about medications, procedures, and any relevant timeline information.
          </p>
        </div>

        <div>
          <label className="form-label">
            Treatment Tags
          </label>
          <TagInput
            tags={tags}
            onAddTag={handleTagAddition}
            onDeleteTag={handleTagDelete}
          />
          <p className="mt-1.5 text-sm text-gray-500">
            Add keywords that describe your treatment. Type and press Enter, or select from suggestions.
            Click the 'x' to remove a tag.
          </p>
        </div>

        <div>
          <label className="form-label" htmlFor="outcome">
            Current Outcome <span className="text-red-500">*</span>
          </label>
          <select
            id="outcome"
            required
            value={formData.outcome}
            onChange={(e) => setFormData(prev => ({ ...prev, outcome: e.target.value }))}
            className="form-input"
          >
            <option value="">Select outcome</option>
            {OUTCOMES.map(outcome => (
              <option key={outcome} value={outcome}>{outcome}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="form-label" htmlFor="timeframe">
            Current Timeframe
          </label>
          <input
            id="timeframe"
            type="text"
            value={formData.timeframe}
            onChange={(e) => setFormData(prev => ({ ...prev, timeframe: e.target.value }))}
            className="form-input"
            placeholder="e.g., 6 months, Since Jan 2024"
          />
          <p className="mt-1.5 text-sm text-gray-500">
            How long have you been on this treatment?
          </p>
        </div>

        {!isUpdate && (
          <div>
            <label className="form-label" htmlFor="email">
              Email for Updates (Optional)
            </label>
            <input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
              className="form-input"
              placeholder="Enter your email address"
            />
            <p className="mt-1.5 text-sm text-gray-500">
              We'll send you a secure link to update your submission later if needed.
            </p>
          </div>
        )}

        <div className="pt-4">
          <button
            type="submit"
            disabled={loading}
            className={`btn-primary w-full flex items-center justify-center ${
              loading ? 'opacity-50 cursor-not-allowed' : ''
            }`}
          >
            {loading ? (
              <>
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Submitting...
              </>
            ) : (
              isUpdate ? 'Submit Treatment Update' : 'Submit Treatment Experience'
            )}
          </button>
        </div>
      </form>
    </div>
  );
}