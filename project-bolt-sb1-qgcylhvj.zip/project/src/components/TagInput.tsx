import React, { useState, useRef, useEffect } from 'react';
import { X, ChevronDown, ChevronUp } from 'lucide-react';
import { TREATMENT_TAG_SUGGESTIONS, TAG_CATEGORIES } from '../types';

interface Tag {
  id: string;
  text: string;
}

interface TagInputProps {
  tags: Tag[];
  onAddTag: (tag: Tag) => void;
  onDeleteTag: (index: number) => void;
}

export default function TagInput({ tags, onAddTag, onDeleteTag }: TagInputProps) {
  const [input, setInput] = useState('');
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});
  const inputRef = useRef<HTMLInputElement>(null);
  const suggestionsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (suggestionsRef.current && !suggestionsRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setInput(value);

    if (value.trim()) {
      const filtered = TREATMENT_TAG_SUGGESTIONS.filter(
        suggestion => suggestion.toLowerCase().includes(value.toLowerCase())
      );
      setSuggestions(filtered);
      setShowSuggestions(true);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  };

  const addTag = (text: string) => {
    const trimmedText = text.trim();
    if (trimmedText && !tags.some(tag => tag.text.toLowerCase() === trimmedText.toLowerCase())) {
      onAddTag({ id: trimmedText, text: trimmedText });
      setInput('');
      setSuggestions([]);
      setShowSuggestions(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      addTag(input);
    } else if (e.key === 'Backspace' && !input && tags.length > 0) {
      onDeleteTag(tags.length - 1);
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    addTag(suggestion);
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  const toggleCategory = (category: string) => {
    setExpandedCategories(prev => ({
      ...prev,
      [category]: !prev[category]
    }));
  };

  const isTagSelected = (text: string) => {
    return tags.some(tag => tag.text.toLowerCase() === text.toLowerCase());
  };

  return (
    <div className="space-y-4">
      {/* Categorized Quick-Select Section */}
      <div className="space-y-3">
        {Object.entries(TAG_CATEGORIES).map(([category, categoryTags]) => (
          <div key={category} className="border border-gray-200 rounded-lg overflow-hidden">
            <button
              type="button"
              onClick={() => toggleCategory(category)}
              className="w-full px-4 py-2 bg-gray-50 text-left flex items-center justify-between hover:bg-gray-100 transition-colors"
            >
              <span className="font-medium text-gray-700">{category}</span>
              {expandedCategories[category] ? (
                <ChevronUp className="h-5 w-5 text-gray-400" />
              ) : (
                <ChevronDown className="h-5 w-5 text-gray-400" />
              )}
            </button>
            
            {expandedCategories[category] && (
              <div className="p-3 bg-white flex flex-wrap gap-2">
                {categoryTags.map(tag => {
                  const selected = isTagSelected(tag);
                  return (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => selected ? onDeleteTag(tags.findIndex(t => t.text === tag)) : addTag(tag)}
                      className={`px-3 py-1.5 rounded-full text-sm font-medium transition-colors ${
                        selected
                          ? 'bg-blue-100 text-blue-700 hover:bg-blue-200'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      {tag}
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Smart Input Field */}
      <div className="relative">
        <div className="form-input min-h-[42px] flex flex-wrap items-center gap-2 p-1.5">
          {tags.map((tag, index) => (
            <span
              key={tag.id}
              className="inline-flex items-center bg-blue-50 text-blue-700 px-2.5 py-1 rounded-md text-sm"
            >
              {tag.text}
              <button
                type="button"
                onClick={() => onDeleteTag(index)}
                className="ml-1.5 text-blue-500 hover:text-blue-700 focus:outline-none"
              >
                <X size={14} />
              </button>
            </span>
          ))}
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={handleInputChange}
            onKeyDown={handleKeyDown}
            onFocus={() => input.trim() && setShowSuggestions(true)}
            className="flex-1 min-w-[120px] outline-none bg-transparent"
            placeholder={tags.length === 0 ? "Add custom tags or type to search..." : ""}
          />
        </div>

        {showSuggestions && suggestions.length > 0 && (
          <div
            ref={suggestionsRef}
            className="absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-auto"
          >
            {suggestions.map((suggestion) => (
              <button
                key={suggestion}
                type="button"
                onClick={() => handleSuggestionClick(suggestion)}
                className="w-full px-4 py-2 text-left text-sm hover:bg-blue-50 focus:bg-blue-50 focus:outline-none"
              >
                {suggestion}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}