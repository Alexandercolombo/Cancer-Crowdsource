import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import type { Submission } from '../types';
import { FileText } from 'lucide-react';

export default function PublicView() {
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedType, setSelectedType] = useState<string>('all');

  useEffect(() => {
    loadSubmissions();
  }, []);

  async function loadSubmissions() {
    try {
      const { data, error } = await supabase
        .from('submissions')
        .select('*')
        .eq('status', 'approved')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setSubmissions(data || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load submissions');
    } finally {
      setLoading(false);
    }
  }

  const filteredSubmissions = selectedType === 'all'
    ? submissions
    : submissions.filter(s => s.cancer_type === selectedType);

  const uniqueTypes = Array.from(new Set(submissions.map(s => s.cancer_type))).sort();

  if (loading) return <div className="text-center py-8">Loading...</div>;
  if (error) return <div className="text-red-600 text-center py-8">{error}</div>;

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-4">Treatment Experiences</h1>
        <p className="text-gray-600 mb-4">
          Browse shared cancer treatment experiences. These submissions have been reviewed and approved for public viewing.
        </p>
        
        <select
          value={selectedType}
          onChange={(e) => setSelectedType(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="all">All Cancer Types</option>
          {uniqueTypes.map(type => (
            <option key={type} value={type}>{type}</option>
          ))}
        </select>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredSubmissions.map((submission) => (
          <div key={submission.id} className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center gap-2 mb-4">
              <FileText className="text-blue-600" size={24} />
              <h2 className="text-xl font-semibold text-gray-800">{submission.cancer_type}</h2>
            </div>
            
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium text-gray-500">Treatment</h3>
                <p className="mt-1 text-gray-800">{submission.treatment_description}</p>
              </div>

              {submission.treatment_tags.length > 0 && (
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Tags</h3>
                  <div className="mt-1 flex flex-wrap gap-2">
                    {submission.treatment_tags.map((tag, i) => (
                      <span
                        key={i}
                        className="inline-block bg-blue-100 text-blue-800 text-sm px-2 py-1 rounded-md"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Outcome</h3>
                  <p className="mt-1 text-gray-800">{submission.outcome}</p>
                </div>

                {submission.timeframe && (
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Timeframe</h3>
                    <p className="mt-1 text-gray-800">{submission.timeframe}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredSubmissions.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          No submissions found for the selected cancer type.
        </div>
      )}
    </div>
  );
}