import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import type { Submission } from '../types';
import { format } from 'date-fns';
import { 
  Clock, 
  PlusCircle, 
  FileText,
  AlertCircle,
  Loader2,
  CheckCircle,
  XOctagon
} from 'lucide-react';

export default function MyUpdates() {
  const navigate = useNavigate();
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    checkAuth();
    loadSubmissions();
  }, []);

  async function checkAuth() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      navigate('/submit');
    }
  }

  async function loadSubmissions() {
    try {
      setError(null);
      const { data, error: fetchError } = await supabase
        .from('submissions')
        .select('*')
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;
      setSubmissions(data || []);
    } catch (err) {
      console.error('Error loading submissions:', err);
      setError(err instanceof Error ? err.message : 'Failed to load submissions');
    } finally {
      setLoading(false);
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return (
          <span className="status-badge status-badge-pending">
            <Clock size={14} className="mr-1" />
            Pending Review
          </span>
        );
      case 'approved':
        return (
          <span className="status-badge status-badge-approved">
            <CheckCircle size={14} className="mr-1" />
            Approved
          </span>
        );
      case 'rejected':
        return (
          <span className="status-badge status-badge-rejected">
            <XOctagon size={14} className="mr-1" />
            Not Approved
          </span>
        );
      default:
        return null;
    }
  };

  const handleAddUpdate = () => {
    // Store the latest submission ID in session storage for pre-filling
    if (submissions.length > 0) {
      sessionStorage.setItem('lastSubmissionId', submissions[0].id);
    }
    navigate('/submit');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">My Shared Experiences</h1>
        <p className="text-gray-600">
          View your submission history and share updates about your treatment journey.
        </p>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-100 rounded-lg flex items-center gap-3 text-red-700">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <div className="mb-8">
        <button
          onClick={handleAddUpdate}
          className="btn-primary inline-flex items-center"
        >
          <PlusCircle className="w-5 h-5 mr-2" />
          Share Latest Progress
        </button>
        <p className="mt-2 text-sm text-gray-500">
          Click above to submit a new update about your current treatment status.
        </p>
      </div>

      <div className="space-y-6">
        {submissions.length === 0 ? (
          <div className="text-center py-12 bg-gray-50 rounded-lg border border-gray-100">
            <FileText className="w-12 h-12 mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              No Submissions Yet
            </h3>
            <p className="text-gray-600">
              Your previous submissions will appear here once they're approved.
            </p>
          </div>
        ) : (
          submissions.map((submission) => (
            <div
              key={submission.id}
              className="bg-white rounded-lg shadow-sm border border-gray-100 p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-gray-900">
                  {submission.cancer_type}
                </h3>
                {getStatusBadge(submission.status)}
              </div>

              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-gray-500 mb-1">
                    Treatment Description
                  </h4>
                  <p className="text-gray-800">{submission.treatment_description}</p>
                </div>

                {submission.treatment_tags.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 mb-2">
                      Treatment Tags
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {submission.treatment_tags.map((tag, index) => (
                        <span
                          key={index}
                          className="inline-block bg-blue-50 text-blue-700 px-2.5 py-1 rounded-md text-sm"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 mb-1">
                      Outcome
                    </h4>
                    <p className="text-gray-800">{submission.outcome}</p>
                  </div>

                  {submission.timeframe && (
                    <div>
                      <h4 className="text-sm font-medium text-gray-500 mb-1">
                        Timeframe
                      </h4>
                      <p className="text-gray-800">{submission.timeframe}</p>
                    </div>
                  )}
                </div>

                <div>
                  <h4 className="text-sm font-medium text-gray-500 mb-1">
                    Submitted
                  </h4>
                  <p className="text-gray-600 text-sm">
                    {format(new Date(submission.created_at), 'PPpp')}
                  </p>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}