import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import type { Submission } from '../types';
import { format } from 'date-fns';
import { 
  CheckCircle2, 
  XCircle, 
  Search, 
  Download, 
  FileText,
  AlertCircle,
  Filter,
  Loader2,
  X,
  Clock,
  CheckCircle,
  XOctagon,
  RefreshCw,
  Edit2,
  Save
} from 'lucide-react';
import { CANCER_TYPES, OUTCOMES } from '../types';
import TagInput from './TagInput';

type StatusFilter = 'all' | 'pending' | 'approved' | 'rejected';

interface Tag {
  id: string;
  text: string;
}

export default function AdminDashboard() {
  const navigate = useNavigate();
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('pending');
  const [selectedSubmission, setSelectedSubmission] = useState<Submission | null>(null);
  const [exportLoading, setExportLoading] = useState(false);
  const [exportError, setExportError] = useState<string | null>(null);
  const [exportSuccess, setExportSuccess] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({
    cancer_type: '',
    treatment_description: '',
    outcome: '',
    timeframe: '',
  });
  const [editTags, setEditTags] = useState<Tag[]>([]);

  useEffect(() => {
    checkAdminAuth();
    loadSubmissions();
  }, [statusFilter]);

  async function checkAdminAuth() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user?.email?.endsWith('@admin.local')) {
      navigate('/admin/login');
    }
  }

  async function loadSubmissions() {
    try {
      setError(null);
      let query = supabase
        .from('submissions')
        .select('*')
        .order('created_at', { ascending: false });

      if (statusFilter !== 'all') {
        query = query.eq('status', statusFilter);
      }

      const { data, error: fetchError } = await query;

      if (fetchError) throw fetchError;
      setSubmissions(data || []);
    } catch (err) {
      console.error('Error loading submissions:', err);
      setError(err instanceof Error ? err.message : 'Failed to load submissions');
    } finally {
      setLoading(false);
    }
  }

  async function updateStatus(id: string, newStatus: 'approved' | 'rejected') {
    try {
      setError(null);
      setActionLoading(true);

      const { error: updateError } = await supabase
        .from('submissions')
        .update({ status: newStatus })
        .eq('id', id);

      if (updateError) throw updateError;
      
      // Update local state
      setSubmissions(submissions.map(sub => 
        sub.id === id ? { ...sub, status: newStatus } : sub
      ));
      
      // If we're filtering by status, remove the item from the list
      if (statusFilter !== 'all' && statusFilter !== newStatus) {
        setSubmissions(submissions.filter(sub => sub.id !== id));
      }
      
      setSelectedSubmission(null);
    } catch (err) {
      console.error('Error updating status:', err);
      setError(err instanceof Error ? err.message : 'Failed to update status');
    } finally {
      setActionLoading(false);
    }
  }

  async function exportCsv() {
    try {
      setExportError(null);
      setExportLoading(true);
      setExportSuccess(false);

      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/export-csv`, {
        headers: {
          Authorization: `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}`,
        },
      });

      if (!response.ok) throw new Error('Export failed');

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `cancer-treatments-${format(new Date(), 'yyyy-MM-dd')}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      setExportSuccess(true);
      setTimeout(() => setExportSuccess(false), 3000);
    } catch (err) {
      console.error('Error exporting CSV:', err);
      setExportError(err instanceof Error ? err.message : 'Export failed');
    } finally {
      setExportLoading(false);
    }
  }

  const handleEditClick = () => {
    if (!selectedSubmission) return;
    
    setEditForm({
      cancer_type: selectedSubmission.cancer_type,
      treatment_description: selectedSubmission.treatment_description,
      outcome: selectedSubmission.outcome,
      timeframe: selectedSubmission.timeframe || '',
    });
    
    setEditTags(selectedSubmission.treatment_tags.map(tag => ({ id: tag, text: tag })));
    setIsEditing(true);
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    setEditForm({
      cancer_type: '',
      treatment_description: '',
      outcome: '',
      timeframe: '',
    });
    setEditTags([]);
  };

  const handleSaveEdit = async () => {
    if (!selectedSubmission) return;

    try {
      setActionLoading(true);
      setError(null);

      const { error: updateError } = await supabase
        .from('submissions')
        .update({
          cancer_type: editForm.cancer_type,
          treatment_description: editForm.treatment_description,
          treatment_tags: editTags.map(tag => tag.text),
          outcome: editForm.outcome,
          timeframe: editForm.timeframe || null,
          status: 'pending' // Always reset to pending after edit
        })
        .eq('id', selectedSubmission.id);

      if (updateError) throw updateError;

      // Update local state
      const updatedSubmission = {
        ...selectedSubmission,
        ...editForm,
        treatment_tags: editTags.map(tag => tag.text),
        status: 'pending'
      };

      setSubmissions(submissions.map(sub =>
        sub.id === selectedSubmission.id ? updatedSubmission : sub
      ));

      // If we're filtering by status, remove the item from the list
      if (statusFilter !== 'all' && statusFilter !== 'pending') {
        setSubmissions(submissions.filter(sub => sub.id !== selectedSubmission.id));
        setSelectedSubmission(null);
      } else {
        setSelectedSubmission(updatedSubmission);
      }

      setIsEditing(false);
    } catch (err) {
      console.error('Error saving edits:', err);
      setError(err instanceof Error ? err.message : 'Failed to save changes');
    } finally {
      setActionLoading(false);
    }
  };

  const filteredSubmissions = submissions.filter(submission => {
    if (!searchQuery) return true;
    
    const searchLower = searchQuery.toLowerCase();
    return (
      submission.treatment_description.toLowerCase().includes(searchLower) ||
      submission.treatment_tags.some(tag => tag.toLowerCase().includes(searchLower)) ||
      submission.cancer_type.toLowerCase().includes(searchLower)
    );
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return (
          <span className="status-badge status-badge-pending">
            <Clock size={14} className="mr-1" />
            Pending
          </span>
        );
      case 'approved':
        return (
          <span className="status-badge status-badge-approved">
            <CheckCircle size={14} className="mr-1" />
            Approved
          </span>
        );
      case 'rejected':
        return (
          <span className="status-badge status-badge-rejected">
            <XOctagon size={14} className="mr-1" />
            Rejected
          </span>
        );
      default:
        return null;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
        <button
          onClick={exportCsv}
          disabled={exportLoading}
          className={`btn-primary flex items-center ${exportLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          {exportLoading ? (
            <>
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              Exporting...
            </>
          ) : (
            <>
              <Download className="w-5 h-5 mr-2" />
              Export Approved Data
            </>
          )}
        </button>
      </div>
      
      {error && (
        <div className="p-4 bg-red-50 border border-red-100 rounded-lg flex items-center gap-2 text-red-700">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <span>{error}</span>
          <button 
            onClick={() => setError(null)}
            className="ml-auto hover:bg-red-100 p-1 rounded-full"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {exportError && (
        <div className="p-4 bg-red-50 border border-red-100 rounded-lg flex items-center gap-2 text-red-700">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <span>{exportError}</span>
          <button 
            onClick={() => setExportError(null)}
            className="ml-auto hover:bg-red-100 p-1 rounded-full"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {exportSuccess && (
        <div className="p-4 bg-green-50 border border-green-100 rounded-lg flex items-center gap-2 text-green-700">
          <CheckCircle className="w-5 h-5 flex-shrink-0" />
          <span>Export successful! Download started.</span>
        </div>
      )}

      <div className="flex flex-wrap gap-4 items-center">
        <div className="relative flex-grow max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
          <input
            type="text"
            placeholder="Search submissions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 pr-4 py-2 w-full border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
            >
              <X size={16} />
            </button>
          )}
        </div>

        <div className="flex items-center gap-2">
          <Filter size={20} className="text-gray-400" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as StatusFilter)}
            className="px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="pending">Pending Review</option>
            <option value="approved">Approved</option>
            <option value="rejected">Rejected</option>
            <option value="all">All Submissions</option>
          </select>
        </div>

        <button
          onClick={loadSubmissions}
          className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg"
          title="Refresh submissions"
        >
          <RefreshCw size={20} />
        </button>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Submissions List */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-4 border-b border-gray-100">
            <h2 className="text-lg font-semibold text-gray-900">
              Submissions
              {filteredSubmissions.length > 0 && (
                <span className="ml-2 text-sm text-gray-500">
                  ({filteredSubmissions.length})
                </span>
              )}
            </h2>
          </div>

          <div className="divide-y divide-gray-100 max-h-[600px] overflow-y-auto">
            {filteredSubmissions.map((submission) => (
              <button
                key={submission.id}
                onClick={() => {
                  setSelectedSubmission(submission);
                  setIsEditing(false);
                }}
                className={`w-full p-4 text-left hover:bg-gray-50 transition-colors ${
                  selectedSubmission?.id === submission.id ? 'bg-blue-50' : ''
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-gray-900">{submission.cancer_type}</span>
                  {getStatusBadge(submission.status)}
                </div>
                <p className="text-sm text-gray-600 line-clamp-2 mb-2">
                  {submission.treatment_description}
                </p>
                <div className="flex items-center text-xs text-gray-500">
                  <Clock size={12} className="mr-1" />
                  {format(new Date(submission.created_at), 'MMM d, yyyy HH:mm')}
                </div>
              </button>
            ))}

            {filteredSubmissions.length === 0 && (
              <div className="p-8 text-center text-gray-500">
                <FileText className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                <p className="font-medium">No submissions found</p>
                <p className="text-sm mt-1">
                  {searchQuery 
                    ? 'Try adjusting your search terms'
                    : `No ${statusFilter === 'all' ? '' : statusFilter} submissions available`
                  }
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Submission Details */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100">
          {selectedSubmission ? (
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-gray-900">Submission Details</h2>
                <div className="flex gap-2">
                  {!isEditing && (
                    <>
                      <button
                        onClick={handleEditClick}
                        className="btn-secondary flex items-center"
                      >
                        <Edit2 size={16} className="mr-2" />
                        Edit
                      </button>
                      {selectedSubmission.status === 'pending' && (
                        <>
                          <button
                            onClick={() => updateStatus(selectedSubmission.id, 'approved')}
                            disabled={actionLoading}
                            className={`btn-primary flex items-center ${
                              actionLoading ? 'opacity-50 cursor-not-allowed' : ''
                            }`}
                          >
                            {actionLoading ? (
                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            ) : (
                              <CheckCircle2 size={16} className="mr-2" />
                            )}
                            Approve
                          </button>
                          <button
                            onClick={() => updateStatus(selectedSubmission.id, 'rejected')}
                            disabled={actionLoading}
                            className={`btn-danger flex items-center ${
                              actionLoading ? 'opacity-50 cursor-not-allowed' : ''
                            }`}
                          >
                            {actionLoading ? (
                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            ) : (
                              <XCircle size={16} className="mr-2" />
                            )}
                            Reject
                          </button>
                        </>
                      )}
                    </>
                  )}
                </div>
              </div>

              {isEditing ? (
                <div className="space-y-6">
                  <div>
                    <label className="form-label" htmlFor="cancer_type">
                      Cancer Type <span className="text-red-500">*</span>
                    </label>
                    <select
                      id="cancer_type"
                      required
                      value={editForm.cancer_type}
                      onChange={(e) => setEditForm(prev => ({ ...prev, cancer_type: e.target.value }))}
                      className="form-input"
                    >
                      <option value="">Select cancer type</option>
                      {CANCER_TYPES.map(type => (
                        <option key={type} value={type}>{type}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="form-label" htmlFor="treatment_description">
                      Treatment Description <span className="text-red-500">*</span>
                    </label>
                    <textarea
                      id="treatment_description"
                      required
                      value={editForm.treatment_description}
                      onChange={(e) => setEditForm(prev => ({ ...prev, treatment_description: e.target.value }))}
                      className="form-input min-h-[120px]"
                    />
                  </div>

                  <div>
                    <label className="form-label">Treatment Tags</label>
                    <TagInput
                      tags={editTags}
                      onAddTag={(tag) => setEditTags([...editTags, tag])}
                      onDeleteTag={(index) => setEditTags(editTags.filter((_, i) => i !== index))}
                    />
                  </div>

                  <div>
                    <label className="form-label" htmlFor="outcome">
                      Outcome <span className="text-red-500">*</span>
                    </label>
                    <select
                      id="outcome"
                      required
                      value={editForm.outcome}
                      onChange={(e) => setEditForm(prev => ({ ...prev, outcome: e.target.value }))}
                      className="form-input"
                    >
                      <option value="">Select outcome</option>
                      {OUTCOMES.map(outcome => (
                        <option key={outcome} value={outcome}>{outcome}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="form-label" htmlFor="timeframe">
                      Timeframe
                    </label>
                    <input
                      id="timeframe"
                      type="text"
                      value={editForm.timeframe}
                      onChange={(e) => setEditForm(prev => ({ ...prev, timeframe: e.target.value }))}
                      className="form-input"
                    />
                  </div>

                  <div className="flex gap-3 pt-4">
                    <button
                      onClick={handleSaveEdit}
                      disabled={actionLoading}
                      className={`btn-primary flex-1 flex items-center justify-center ${
                        actionLoading ? 'opacity-50 cursor-not-allowed' : ''
                      }`}
                    >
                      {actionLoading ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Save size={16} className="mr-2" />
                      )}
                      Save Changes
                    </button>
                    <button
                      onClick={handleCancelEdit}
                      disabled={actionLoading}
                      className="btn-secondary flex-1"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-1">Status</h3>
                    {getStatusBadge(selectedSubmission.status)}
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-1">Cancer Type</h3>
                    <p className="text-gray-900">{selectedSubmission.cancer_type}</p>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-1">Treatment Description</h3>
                    <p className="text-gray-900 whitespace-pre-wrap">
                      {selectedSubmission.treatment_description}
                    </p>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-1">Treatment Tags</h3>
                    <div className="flex flex-wrap gap-2">
                      {selectedSubmission.treatment_tags.map((tag, index) => (
                        <span
                          key={index}
                          className="inline-block bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-sm"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-sm font-medium text-gray-500 mb-1">Outcome</h3>
                      <p className="text-gray-900">{selectedSubmission.outcome}</p>
                    </div>

                    {selectedSubmission.timeframe && (
                      <div>
                        <h3 className="text-sm font-medium text-gray-500 mb-1">Timeframe</h3>
                        <p className="text-gray-900">{selectedSubmission.timeframe}</p>
                      </div>
                    )}
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-1">Submission Date</h3>
                    <p className="text-gray-900">
                      {format(new Date(selectedSubmission.created_at), 'PPpp')}
                    </p>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="p-8 flex flex-col items-center justify-center text-gray-500">
              <FileText size={48} className="mb-4" />
              <p className="font-medium">Select a submission to view details</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}