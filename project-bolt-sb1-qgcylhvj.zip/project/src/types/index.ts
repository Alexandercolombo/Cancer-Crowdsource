export interface Submission {
  id: string;
  created_at: string;
  updated_at: string;
  anon_user_id?: string;
  cancer_type: string;
  treatment_description: string;
  treatment_tags: string[];
  outcome: string;
  timeframe?: string;
  status: 'pending' | 'approved' | 'rejected';
  user_email_hash?: string;
}

export const CANCER_TYPES = [
  'Breast',
  'Lung',
  'Prostate',
  'Colorectal',
  'Melanoma',
  'Leukemia',
  'Lymphoma',
  'Brain',
  'Ovarian',
  'Pancreatic',
  'Liver',
  'Kidney',
  'Bladder',
  'Thyroid',
  'Other'
] as const;

export const OUTCOMES = [
  'Shrinking',
  'Stable',
  'No Change',
  'Worsening',
  'Other'
] as const;

export const TAG_CATEGORIES = {
  'Conventional Treatments': [
    'Chemotherapy',
    'Radiation',
    'Surgery',
    'Immunotherapy',
    'Targeted Therapy',
    'Hormone Therapy',
    'Clinical Trial'
  ],
  'Diet & Nutrition': [
    'Fasting',
    'Ketogenic Diet',
    'Plant-Based Diet',
    'Juicing',
    'Supplements',
    'Vitamin C',
    'Vitamin D'
  ],
  'Mind & Body': [
    'Exercise',
    'Yoga',
    'Meditation',
    'Acupuncture',
    'Physical Therapy',
    'Massage'
  ],
  'Support & Care': [
    'Pain Management',
    'Anti-Nausea',
    'Support Group',
    'Counseling',
    'Palliative Care'
  ],
  'Treatment Status': [
    'Ongoing',
    'Completed',
    'Early Stage',
    'Advanced Stage',
    'Maintenance'
  ]
} as const;

// Flatten tag categories for autocomplete
export const TREATMENT_TAG_SUGGESTIONS = Object.values(TAG_CATEGORIES).flat();